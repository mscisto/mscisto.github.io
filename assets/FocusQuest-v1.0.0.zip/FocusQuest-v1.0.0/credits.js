const backreturnmenu = document.getElementById("back-to-menu-button");
const creditstheme = new Audio("assets/audio/credits.mp3");

creditstheme.volume = 0.3;
creditstheme.loop = true;
creditstheme.play();

backreturnmenu.addEventListener("click", () => {
    creditstheme.pause();
    creditstheme.currentTime = 0;
    window.location.href = "menu.html"
});