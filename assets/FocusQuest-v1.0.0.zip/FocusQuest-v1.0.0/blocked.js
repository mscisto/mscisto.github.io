const blockedTimer = document.getElementById("blocked-timer");
const returnButton = document.getElementById("return-button");
const blockedDomain = document.getElementById("blocked-domain");
const salelaugh = new Audio("assets/audio/Laugh.mp3");
const params = new URLSearchParams(window.location.search);
const blockedSite = params.get("site");
const FinalTolls = new Audio("assets/audio/FinalHours.mp3");


// Blocked Music
salelaugh.volume = 1;
salelaugh.play();
salelaugh.loop= true;
FinalTolls.volume = 0.2;
FinalTolls.loop = true;
FinalTolls.play();


if (blockedSite) {
    blockedDomain.textContent = blockedSite;
}


chrome.storage.local.get(["questEndTime"], (result) => {
    const questEndTime = result.questEndTime;

    if (!questEndTime) {
        blockedTimer.textContent = "--:--";
        return;
    }

updateBlockedTimer(questEndTime);

setInterval(() => {
    updateBlockedTimer(questEndTime);
}, 1000);

});

function updateBlockedTimer(questEndTime) {
    const remaining = questEndTime - Date.now();


    if (remaining <= 0) {
        blockedTimer.textContent = "00:00";
        return;
    }

    const totalSeconds = Math.ceil(remaining/1000);

    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    blockedTimer.textContent = `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

returnButton.addEventListener("click", () => {
    salelaugh.pause();
    FinalTolls.pause();
    salelaugh.currentTime = 0;
    FinalTolls.currentTime = 0;
    window.location.href = "menu.html";
})