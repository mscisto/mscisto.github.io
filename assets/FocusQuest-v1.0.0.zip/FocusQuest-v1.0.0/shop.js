// --------------------
// SHOP ELEMENTS
// --------------------

const rupeeCount = document.getElementById("shop-rupee-count");
const backButton = document.getElementById("back-button");
const shopButtons = document.querySelectorAll(".shop-item-button");

// --------------------
// SHOP MUSIC
// --------------------

const shopMusic = new Audio("assets/audio/shop-theme.mp3");
const beedlethx = new Audio("assets/audio/beedle.mp3");

shopMusic.loop = true;
shopMusic.volume = 0.4;

beedlethx.volume = 0.7;

// --------------------
// START SHOP MUSIC
// --------------------

shopMusic.play();

// ---------------------
// SHOP STATE
// ---------------------

let currentRupees = 0;
let ownedSongs = ["tarm-ruins"];
let equippedSong = "tarm-ruins";


// --------------------
// LOAD RUPEES
// --------------------

chrome.storage.local.get(["rupees", "ownedSongs", "equippedSong"], (result) => {

    currentRupees = result.rupees || 0;

    ownedSongs = result.ownedSongs || ["tarm-ruins"];

    equippedSong = result.equippedSong || "tarm-ruins";

    updateShop();
});

// --------------------
// UPDATE SHOP DISPLAY
// --------------------

function updateShop() {
    // Update Rupee Counter
    rupeeCount.textContent = currentRupees.toString().padStart(3, "0");

    shopButtons.forEach((button) => {
        const song = button.dataset.song;
        const price = Number(button.dataset.price);
        const card = button.closest(".music-card");
        const priceDisplay = card.querySelector(".price");


        // Equip

        if (song === equippedSong) {
            button.textContent = "Equipped";
            button.disabled = true;

            button.classList.remove("buy-button");
            button.classList.remove("equip-button");
            button.classList.add("equipped-button");
            
            // Hide Price
            if (priceDisplay) {
                priceDisplay.style.visibility = "hidden";
            }

            return;
        }
        // Already Purchased

        if (ownedSongs.includes(song)){

            button.textContent = "Equip";
            button.disabled = false;

            button.classList.remove("buy-button");
            button.classList.remove("equipped-button");
            button.classList.add("equip-button");

             if (priceDisplay) {
                priceDisplay.style.visibility = "hidden";
            }

            return;
        }

        // Cannot Afford
        if (currentRupees < price) {
            button.textContent = "Not Enough Rupees";
            button.disabled = true;
             return;
        }

        // Can Purchase
        button.textContent = "Purchase";
        button.disabled = false;

        button.classList.remove("owned-button");
        button.classList.remove("equipped-button");
        button.classList.add("buy-button");
    });
}


// --------------------
// BUY MUSIC
// --------------------

shopButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const song = button.dataset.song;
        const price = Number(button.dataset.price);

        //Equip Songs

    if (ownedSongs.includes(song)) {
        equippedSong = song;
        chrome.storage.local.set({
        equippedSong: equippedSong
        }, () => {
        console.log(`Equipped ${song}`);
        updateShop();
        });
        return;
    }

        // Safety check: Don't Buy Twice
        if (ownedSongs.includes(song)) {
            return;
        }


        // Safety Check:
        // Make sure player can afford it
        if (currentRupees < price) {
            return;
        }

        // Subtract the price
        currentRupees -= price;

        //Add song to collection
        ownedSongs.push(song);

        //Save BOTH changes
        chrome.storage.local.set({
            rupees: currentRupees,
            ownedSongs: ownedSongs
        
    }, () => {
        console.log(`Purchased ${song} for ${price} rupees`);

        //Beedle's Thank-You Sound
        beedlethx.currentTime = 0;
        beedlethx.play();

        updateShop();
        });
    });
});

// --------------------
// BACK BUTTON
// --------------------

backButton.addEventListener("click", () => {

    shopMusic.pause();
    shopMusic.currentTime = 0;

    window.location.href = "menu.html";
});