// --------------------
// ELEMENTS
// --------------------

const backButton = document.getElementById("back-button");
const minishCapButton = document.getElementById("minish-cap-button");
const beginQuestButton = document.getElementById("begin-quest");
const timerDisplay = document.getElementById("timer-display");
const abandonQuestButton = document.getElementById("abandon-quest-button");
const earthMilestone = document.getElementById("earth-milestone");
const fireMilestone = document.getElementById("fire-milestone");
const waterMilestone = document.getElementById("water-milestone");
const windMilestone = document.getElementById("wind-milestone");
const swordMilestone = document.getElementById("sword-milestone");

// --------------------
// MUSIC
// --------------------

const minishCaptitle =
    new Audio("assets/audio/minish-cap-title.mp3");

minishCaptitle.volume = 0.4;
minishCaptitle.currentTime = 0;
minishCaptitle.play();


// --------------------
// TIMER
// --------------------

let timerInterval;


// --------------------
// BACK BUTTON
// --------------------

backButton.addEventListener("click", () => {

    window.location.href = "menu.html";

});


// --------------------
// QUEST UI STATES
// --------------------

function setQuestActive() {

    beginQuestButton.textContent = "Quest In Progress";
    beginQuestButton.disabled = true;

    abandonQuestButton.style.display = "block";

}


function setQuestInactive() {

    clearInterval(timerInterval);

    timerDisplay.textContent = "30:00";

    beginQuestButton.textContent = "Begin Quest";
    beginQuestButton.disabled = false;

    abandonQuestButton.style.display = "none";

}


// --------------------
// BEGIN QUEST
// --------------------

beginQuestButton.addEventListener("click", () => {
    chrome.storage.local.get(
        ["activeQuest","questStartTime", "questEndTime"],
        (result) => {

            // If Minish Cap is already running,
            // don't allow another quest to start.

            if (
                result.activeQuest === "minish-cap" &&
                result.questEndTime > Date.now()
            ) {

                startTimer(result.questEndTime, result.questStartTime);

                setQuestActive();

                return;

            } 

            // --------------------
            // TEST QUEST LENGTH
            // --------------------

            // 30 minute Minish Cap quest
            const questLength = 30 * 60 * 1000;

            const startTime = Date.now();
            const endTime = startTime + questLength;


            // --------------------
            // SAVE QUEST
            // --------------------

            chrome.storage.local.set({

                activeQuest: "minish-cap",
                questStartTime: startTime,
                questEndTime: endTime

            }, () => {

                startTimer(endTime, startTime);

                setQuestActive();


                // Tell background.js that
                // the quest has started.

                chrome.runtime.sendMessage({

                    type: "QUEST_STARTED",
                    quest: "minish-cap",
                    startTime: startTime,
                    endTime: endTime

                });

            });

        }
    );

});


// --------------------
// ABANDON QUEST
// --------------------

abandonQuestButton.addEventListener("click", () => {

    const confirmed = confirm(
        "Abandon this quest? You will not earn any Rupees."
    );


    // Player pressed Cancel
    if (!confirmed) {

        return;

    }


    // Tell background.js to cancel
    // the active quest.

    chrome.runtime.sendMessage({

        type: "QUEST_ABANDONED",
        quest: "minish-cap"

    });


    // Immediately reset this page's UI.

    setQuestInactive();

});


// --------------------
// START TIMER
// --------------------

function startTimer(endTime, startTime) {

    clearInterval(timerInterval);
    updateMilestones(startTime);  

    timerInterval = setInterval(() => {
    updateMilestones(startTime);   
        const now = Date.now();

        const remainingTime =
            endTime - now;


        // --------------------
        // QUEST FINISHED
        // --------------------

        if (remainingTime <= 0) {

            clearInterval(timerInterval);

            timerDisplay.textContent =
                "Quest Complete!";

            beginQuestButton.textContent =
                "Begin Quest";

            beginQuestButton.disabled =
                false;

            abandonQuestButton.style.display =
                "none";

            return;

        }


        // --------------------
        // DISPLAY TIME
        // --------------------

        const totalSeconds =
            Math.floor(remainingTime / 1000);

        const minutes =
            Math.floor(totalSeconds / 60);

        const seconds =
            totalSeconds % 60;


        timerDisplay.textContent =
            `${minutes}:${seconds
                .toString()
                .padStart(2, "0")}`;

    }, 1000);

}


// --------------------
// RESTORE ACTIVE QUEST
// --------------------

chrome.storage.local.get(
    ["activeQuest", "questStartTime", "questEndTime"],
    (result) => {

        if (
            result.activeQuest === "minish-cap" &&
            result.questEndTime > Date.now()
        ) {

            startTimer(result.questEndTime, result.questStartTime);

            setQuestActive();

        } else {

            setQuestInactive();

        }

    }
);

// --------------------
// ACQUIRED ELEMENTS
// --------------------

function setMilestoneAcquired(card) {
    card.classList.add("acquired");

    const timeText = card.querySelector(".quest-time");
    timeText.textContent = "ACQUIRED ✓";
}

function updateMilestones(questStartTime) {
    const elapsed = Date.now() - questStartTime;

    if (elapsed >= 6 * 60 * 1000) {
        setMilestoneAcquired(earthMilestone);
    }

    if (elapsed >= 12 * 60 * 1000) {
        setMilestoneAcquired(fireMilestone);
    }

    if (elapsed >= 18 * 60 * 1000) {
        setMilestoneAcquired(waterMilestone);
    }

    if (elapsed >= 24 * 60 * 1000) {
        setMilestoneAcquired(windMilestone);
    }

    if (elapsed >= 30 * 60 * 1000) {
        setMilestoneAcquired(swordMilestone);
    }
}