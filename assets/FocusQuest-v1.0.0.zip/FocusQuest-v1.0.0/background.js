chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("menu.html")
  });
});
let completionInProgress = false;

function removeBlockingRules() {
  chrome.declarativeNetRequest.getDynamicRules((currentRules) => {
    const ruleIds = currentRules.map(rule => rule.id);

    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: ruleIds
    });
    chrome.declarativeNetRequest.getDynamicRules((currentRules) => {
  console.log("ACTIVE DNR RULES:", currentRules);
});
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "QUEST_STARTED") {

    chrome.tabs.query({}, async (tabs) => {

      for (const tab of tabs) {

        if (!tab.id) {
          continue;
        }

        try {

          // First try talking to an existing hud.js
          await chrome.tabs.sendMessage(tab.id, message);

        } catch (error) {

          // No hud.js exists on this tab yet.
          try {

            await chrome.scripting.insertCSS({
              target: { tabId: tab.id },
              files: ["hud.css"]
            });

            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ["hud.js"]
            });

            // IMPORTANT:
            // Now that hud.js exists, send QUEST_STARTED again.
            await chrome.tabs.sendMessage(tab.id, message);

          } catch (injectionError) {

            // Normal for protected Chrome pages.
            console.log(
              "Focus Quest could not load on:",
              tab.url
            );

          }

        }

      }

    });
chrome.storage.local.get(["blockedSites"], (result) => {

  const blockedSites = result.blockedSites || [];
  const rules = [];
  let ruleId = 1;

  blockedSites.forEach((site, index) => {

    const rule = {
      id: ruleId++,
      priority: 1,

      action: {
        type: "redirect",
        redirect: {
          url: chrome.runtime.getURL(`blocked.html?site=${encodeURIComponent(site.domain)}`)
        }
      },

      condition: {
    urlFilter: `||${site.domain}/`,
    resourceTypes: ["main_frame"]
  }
    };

    rules.push(rule);
    site.exceptions.forEach((exception) => {
    const exceptionRule = {
        id: ruleId++,
        priority: 2,

        action: {
            type: "allow"
        },

        condition: {
            urlFilter: `|${exception}|`,
            resourceTypes: ["main_frame"]
        }
    };

    rules.push(exceptionRule);
    });
  });

console.log("ABOUT TO ADD RULES:", rules);

chrome.declarativeNetRequest.updateDynamicRules({
  addRules: rules
}, () => {

  if (chrome.runtime.lastError) {
    console.error(
      "DNR ERROR:",
      chrome.runtime.lastError.message
    );
    return;
  }

  console.log("DNR update succeeded");

  chrome.declarativeNetRequest.getDynamicRules((currentRules) => {
    console.log("ACTIVE DNR RULES:", currentRules);
  });

});

});



  }
  if (message.type === "QUEST_COMPLETED" && message.quest === "minish-cap") {
   
    removeBlockingRules();
    console.log("Background Received Quest_Completed");

    if (completionInProgress) {
      return;
    }

    completionInProgress = true;

    chrome.storage.local.get(
      ["rupees", "activeQuest"],
      (result) => {
        console.log("storage at completion:", result);
        if (result.activeQuest !== "minish-cap") {
          completionInProgress = false;
          return;
        }

        const currentRupees = result.rupees || 0;
        const newRupees = currentRupees + 50;

        chrome.storage.local.set({
          rupees: newRupees,
          minishCapCompleted: true,
          activeQuest: null,
          questStartTime: null,
          questEndTime: null
        }, () => {
          console.log(
            `Minish Cap complete! Rupees: ${newRupees}`
          );

          completionInProgress = false;
        });
      }
    );
  }
if (
  message.type === "QUEST_ABANDONED" &&
  message.quest === "minish-cap"
) {
  removeBlockingRules();
  console.log("Background received QUEST_ABANDONED");

  chrome.storage.local.get(
    ["activeQuest"],
    (result) => {

      // Only abandon if Minish Cap is actually active.
      if (result.activeQuest !== "minish-cap") {
        return;
      }

      // Clear the active quest.
      // Notice: we DO NOT touch rupees.
      chrome.storage.local.set({
        activeQuest: null,
        questStartTime: null,
        questEndTime: null
      }, () => {

        console.log("Minish Cap abandoned");

        // Tell every open tab to remove its HUD.
        chrome.tabs.query({}, (tabs) => {

          for (const tab of tabs) {

            if (!tab.id) {
              continue;
            }

            chrome.tabs.sendMessage(
              tab.id,
              {
                type: "QUEST_ABANDONED",
                quest: "minish-cap"
              }
            ).catch(() => {
              // Expected on Chrome's protected pages.
            });

          }

        });

      });

    }
  );
}
  
});