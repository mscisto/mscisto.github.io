const ELEMENT_URLS = {
  earth: chrome.runtime.getURL("assets/images/earth-element.png"),
  fire: chrome.runtime.getURL("assets/images/fire-element.png"),
  water: chrome.runtime.getURL("assets/images/water-element.png"),
  wind: chrome.runtime.getURL("assets/images/wind-element.png")
};

const SCENE_URLS = {
  minish: chrome.runtime.getURL(
    "assets/images/minish-woods-version3.png"
  ),

  earth: chrome.runtime.getURL(
    "assets/images/mt-crenel.png"),

  fire: chrome.runtime.getURL("assets/images/castor-wilds.png"),

  water: chrome.runtime.getURL("assets/images/cloud-tops.png"),

  wind: chrome.runtime.getURL("assets/images/elemental-sanctuary.png")
};

const FOUR_SWORD_AUDIO_URL = 
  chrome.runtime.getURL("assets/audio/four-sword-get.wav");

const FOUR_SWORD_URL =
  chrome.runtime.getURL("assets/images/four-sword-restored-fullbody.png");

chrome.runtime.onMessage.addListener((message) => {

  // Quest Started
  if (
    message.type === "QUEST_STARTED" &&
    message.quest === "minish-cap"
  ) {
    createHud(message.startTime,message.endTime);
  }

  // Quest Abandoned

  if (message.type === "QUEST_ABANDONED" && message.quest === "minish-cap")
  {
     const hud =
     document.getElementById("focus-quest-hud");
    if (hud) {
      hud.remove();
    }
    console.log("Focus Quest HUD removed");
  }
});

const FINAL_LINK_URLS = {
  green: chrome.runtime.getURL("assets/images/final-green-link-skyward.png"),
  red: chrome.runtime.getURL("assets/images/final-red-link-skyward.png"),
  blue: chrome.runtime.getURL("assets/images/final-blue-link-skyward.png"),
  purple: chrome.runtime.getURL("assets/images/final-purple-link-skyward.png"),
}

chrome.storage.local.get(
  ["activeQuest", "questStartTime", "questEndTime"],
  (result) => {

    if (
      result.activeQuest === "minish-cap" &&
      result.questEndTime > Date.now()
    ) {
      createHud(result.questStartTime, result.questEndTime);
    }

  }
);



function watchQuestMilestones(startTime, elementGetAudio) {


  const elapsedTime = Date.now() - startTime;

  let earthTriggered = elapsedTime >= 6 * 60 *1000;
  let fireTriggered = elapsedTime >= 12 * 60 *1000;
  let waterTriggered = elapsedTime >= 18 * 60 *1000;
  let windTriggered = elapsedTime >= 24 * 60 *1000;

// Restore collected elements on a newly-created HUD

if (earthTriggered) {
    const earth =
        document.getElementById("collected-earth");

    earth.style.backgroundImage =
        `url("${ELEMENT_URLS.earth}")`;

    earth.classList.add("collected");
}

if (fireTriggered) {
    const fire =
        document.getElementById("collected-fire");

    fire.style.backgroundImage =
        `url("${ELEMENT_URLS.fire}")`;

    fire.classList.add("collected");
}

if (waterTriggered) {
    const water =
        document.getElementById("collected-water");

    water.style.backgroundImage =
        `url("${ELEMENT_URLS.water}")`;

    water.classList.add("collected");
}

if (windTriggered) {
    const wind =
        document.getElementById("collected-wind");

    wind.style.backgroundImage =
        `url("${ELEMENT_URLS.wind}")`;

    wind.classList.add("collected");
}

  if (windTriggered) {
        changeScene("wind");

  } else if (waterTriggered) {
        changeScene("water");

  } else if (fireTriggered) {
        changeScene("fire");

  } else if (earthTriggered) {
        changeScene("earth");
  }


  function checkMilestones() {

    const hud = document.getElementById("focus-quest-hud");

    if (!hud) {
      return;
    }

    const elapsedTime = Date.now() - startTime;

    console.log(
      "Start time:", startTime,
      "Elapsed:", elapsedTime
    );

    // Earth Element
    if (elapsedTime >= 6 * 60 * 1000 && !earthTriggered) {
      earthTriggered = true;

      console.log("6 minute milestone reached!");

      triggerElement("earth", elementGetAudio);
    }
    // Fire Element
    if (elapsedTime >= 12 * 60 * 1000 && !fireTriggered) {
      fireTriggered = true;
      console.log("12 minute milestone reached!");
      triggerElement("fire", elementGetAudio);
    } 
    if (elapsedTime >= 18 * 60 * 1000 && !waterTriggered) {
      waterTriggered = true;
      console.log("18 minute milestone reached!");
      triggerElement("water", elementGetAudio);
    }
    if (elapsedTime >= 24 * 60 * 1000 && !windTriggered) {
      windTriggered = true;
      console.log("24 minute milestone reached!");
      triggerElement("wind", elementGetAudio);
    }

    setTimeout(checkMilestones, 250);
  }

  checkMilestones();
}

// CREATE THE HUD

function createHud(startTime, endTime) {

  if (document.getElementById("focus-quest-hud")) {
    return;
  }
  const hud = document.createElement("div");
  hud.id = "focus-quest-hud";

  hud.innerHTML = `
    <div id="focus-quest-hud-title">
      The Minish Cap
    </div>

    <div id="focus-quest-scene">
     <div id="minish-woods-background"></div>
     <div id="link-walk-sprite"></div>
     <div id="link-item-get-sprite"></div>
     <div id="element-acquisition"></div>
     <div id="four-sword-restored-sprite"></div>
    
      <div id="four-links-finale">
        <div id="final-green-link" class="final-link"></div>
        <div id="final-red-link" class="final-link"></div>
        <div id="final-blue-link" class="final-link"></div>
        <div id="final-purple-link" class="final-link"></div>
      </div>
    </div>
    <div id="collected-elements">
      <div id="collected-earth" class="collected-element"></div>
      <div id="collected-fire" class="collected-element"></div>
      <div id="collected-water" class="collected-element"></div>
      <div id="collected-wind" class="collected-element"></div>
    </div>

    <div id="focus-quest-hud-timer">
      30:00
    </div>
    <div id="quest-reward"></div>
  `;

  document.body.appendChild(hud);
  document.getElementById("final-green-link").style.backgroundImage =
  `url("${FINAL_LINK_URLS.green}")`;
  document.getElementById("final-red-link").style.backgroundImage =
  `url("${FINAL_LINK_URLS.red}")`;
  document.getElementById("final-blue-link").style.backgroundImage =
  `url("${FINAL_LINK_URLS.blue}")`;
  document.getElementById("final-purple-link").style.backgroundImage =
  `url("${FINAL_LINK_URLS.purple}")`;
  const elementGetAudio = new Audio(chrome.runtime.getURL("assets/audio/receive-element.mp3"));
  elementGetAudio.volume = 0.05;
  const fourSwordAudio = new Audio(chrome.runtime.getURL("assets/audio/four-sword-get.wav"));
  fourSwordAudio.volume = 0.05;
  const linkSprite = document.getElementById("link-walk-sprite");
  const spriteUrl = chrome.runtime.getURL("assets/images/link-walk-left.png");
  linkSprite.style.backgroundImage = `url("${spriteUrl}")`;
  const itemGetSprite = document.getElementById("link-item-get-sprite");
  if (!itemGetSprite) {
  console.log("ERROR: item-get Link div not found!");
  } else {
  const itemGetUrl =
    chrome.runtime.getURL("assets/images/link-item-get.png");
    itemGetSprite.style.backgroundImage =
    `url("${itemGetUrl}")`;
    itemGetSprite.style.display = "none";
  }
  const scenery = document.getElementById("minish-woods-background");
  const sceneryUrl = SCENE_URLS.minish;
  scenery.style.backgroundImage = `url("${sceneryUrl}")`;
  scenery.classList.add("minish-scroll");
  updateHudTimer(endTime, fourSwordAudio);
  const fourSwordSprite =
  document.getElementById("four-sword-restored-sprite");
  fourSwordSprite.style.backgroundImage = `url("${FOUR_SWORD_URL}")`;
  watchQuestMilestones(startTime, elementGetAudio);

}



function triggerElement(elementName, elementGetAudio) {
  const scene = document.getElementById("focus-quest-scene");

  if (!scene) {
    return;
  }

  scene.classList.add("paused");

  const walkingLink = document.getElementById("link-walk-sprite");

  const itemGetLink = document.getElementById("link-item-get-sprite");
  
setTimeout(() => {

 if (walkingLink) {
  walkingLink.style.display = "none";
  } 
  if (itemGetLink) {
  itemGetLink.style.display = "block";
  itemGetLink.classList.add("animate");
  } else {
  console.log("ERROR: item-get Link div missing during Earth trigger");
  }

  elementGetAudio.currentTime = 0;
  elementGetAudio.play();

 }, 800);

const element =
  document.getElementById("element-acquisition");

const elementUrl = ELEMENT_URLS[elementName];

element.style.backgroundImage =
  `url("${elementUrl}")`;

element.classList.add("visible");

setTimeout(() => {

  const collectedElement =
    document.getElementById(`collected-${elementName}`);

  if (collectedElement) {
    collectedElement.style.backgroundImage =
      `url("${elementUrl}")`;

    collectedElement.classList.add("collected");
  }

  if (element) {
    element.classList.remove("visible");
  }

  if (itemGetLink) {
    itemGetLink.style.display = "none";
    itemGetLink.classList.remove("animate");
  }

  if (walkingLink) {
    walkingLink.style.display = "block";
  }

  changeScene(elementName);
  scene.classList.remove("paused");

}, 2200);

console.log(`${elementName} Element Milestone!`);

}

// SCENE CHANGE
function changeScene(elementName) {

  const scenery = document.getElementById("minish-woods-background");

  if (!scenery) {
    return;
  }
  if (elementName === "earth") {
    scenery.style.backgroundImage =
      `url("${SCENE_URLS.earth}")`;
      scenery.classList.remove("minish-scroll");
      scenery.classList.add("crenel-scroll");
  }

  if (elementName === "fire") {
    scenery.style.backgroundImage =
      `url("${SCENE_URLS.fire}")`;
    scenery.classList.remove(
      "minish-scroll",
      "crenel-scroll",
      "castor-scroll"
    );

    scenery.classList.add("castor-scroll");
  }

  if (elementName === "water") {
    scenery.style.backgroundImage = `url("${SCENE_URLS.water}")`;

    scenery.classList.remove(
      "minish-scroll",
      "crenel-scroll",
      "castor-scroll",
      "cloud-scroll"
    );

    scenery.classList.add("cloud-scroll");
  }

  if (elementName === "wind") {
    scenery.style.backgroundImage = `url("${SCENE_URLS.wind}")`;

    scenery.classList.remove(
      "minish-scroll",
      "crenel-scroll",
      "castor-scroll",
      "cloud-scroll"
    );
    scenery.classList.add("elemental-scroll");
  }
  
}

function updateHudTimer(endTime, fourSwordAudio) {

  const timer = document.getElementById("focus-quest-hud-timer");

  function update() {

    // Stop if the HUD has been removed
    if (!document.getElementById("focus-quest-hud")) {
      return;
    }

    const remainingTime = endTime - Date.now();

    if (remainingTime <= 0) {

      triggerFourSwordFinale(fourSwordAudio);
      return;
    }

    const totalSeconds = Math.ceil(remainingTime / 1000);

    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    timer.textContent =
      `${minutes}:${seconds.toString().padStart(2, "0")}`;

    // Run update() again in 250 milliseconds
    setTimeout(update, 250);
  }

  update();
}

function triggerFourSwordFinale(fourSwordAudio) {
  const scene = document.getElementById("focus-quest-scene");
  const walkingLink = document.getElementById("link-walk-sprite");
  const timer = document.getElementById("focus-quest-hud-timer");
  const fourSwordSprite = document.getElementById("four-sword-restored-sprite");


  if (!scene) {
    return;
  }
  scene.classList.add("paused");

  if (walkingLink) {
    walkingLink.style.display = "none";
  }

  if (fourSwordSprite) {
    fourSwordSprite.style.display = "block";
    fourSwordSprite.classList.add("animate");

    fourSwordAudio.currentTime = 0;
    fourSwordAudio.play();
    setTimeout(() => {
    scene.classList.add("finale-flash");
      }, 900);
    setTimeout(() => {
      scene.classList.remove("finale-flash");
      }, 1200);
    setTimeout(() => {
    const fourLinks = document.getElementById("four-links-finale");
    if (fourSwordSprite) {
    fourSwordSprite.style.display = "none";}
    if (fourLinks) {fourLinks.classList.add("visible");}
    if (timer) {timer.textContent = "Quest Complete!";}
    const reward = document.getElementById("quest-reward");
    if (reward) {
        reward.textContent = "+50 Rupees";
        reward.classList.add("visible");
      }
      chrome.runtime.sendMessage({
        type: "QUEST_COMPLETED",
        quest: "minish-cap"
      });

    console.log("HUD sent QUEST_COMPLETED");
    setTimeout(() => {
      const hud = document.getElementById("focus-quest-hud");

      if (hud) {
        hud.remove();
        console.log("Final HUD removed");
      }
    }, 4000);
  }, 1200);
}
if (timer) {
    timer.textContent = "The Four Sword...";
  }
  console.log("Four Sword finale started!");
}
