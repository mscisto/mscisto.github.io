const MENU_SONGS = {
    "tarm-ruins": "assets/audio/tarm-ruins.mp3",
    "elemental-sanctuary": "assets/audio/elemental-sanctuary.mp3",
    "seal-seven-maidens": "assets/audio/seal-seven-maidens.mp3",
    "four-sword-select": "assets/audio/name-select.mp3",
}

let menuMusic = null;

function playEquippedMusic() {
    chrome.storage.local.get(
        ["equippedSong"],
        (result) => {
            const equippedSong = result.equippedSong || "tarm-ruins";
            const songFile = MENU_SONGS[equippedSong];
            if (!songFile) {
                console.log(`Unknown equipped song: ${equippedSong}`);
                return;
            }
            menuMusic = new Audio(songFile);
            menuMusic.loop = true;
            menuMusic.volume = 0.4;
            menuMusic.play();
            console.log(`Now playing: ${equippedSong}`);
        }
    );
}

const nameScreen = document.getElementById("name-screen");
const nameInput = document.getElementById("player-name-input");
const confirmButton = document.getElementById("confirm-name");
const playerNameDisplay = document.getElementById("player-name");
const nameSelectMusic = new Audio("assets/audio/name-select.mp3");
const confirmSound = new Audio("assets/audio/confirm.mp3");
const tarmruins = new Audio("assets/audio/tarm-ruins.mp3");
const minishCapButton = document.getElementById("minish-cap-button");
const minishCaptitle = new Audio("assets/audio/minish-cap-title.mp3");
const rupeeCount = document.getElementById("rupee-count");
const rupeeIcon = document.getElementById("rupee-icon");
const shopButton = document.getElementById("shop-button");
const blockButton = document.getElementById("block-list-button");
const creditsButton = document.getElementById("credits-button");


minishCaptitle.loop = true;
minishCaptitle.volume = 0.4;
nameSelectMusic.loop = true;
nameSelectMusic.volume = 0.4;
confirmSound.volume = 0.5;
tarmruins.volume = 0.4;
tarmruins.loop = true;

function animateRupees(start, end){
    let current = start;
    rupeeIcon.classList.add("counting");
    const duration = 1000;
    const steps = 25;
    const intervalTime = duration / steps;

    const amountPerStep = Math.max(1, Math.ceil((end - start)/steps));

    const counter = setInterval(() => {
        current += amountPerStep;

        if (current >= end) {
            current = end;
            clearInterval(counter);
            rupeeIcon.classList.remove("counting");
        }

        rupeeCount.textContent = current.toString().padStart(3, "0");
    }, intervalTime);

}


//SHOP BUTTON

shopButton.addEventListener("click", () => {
    window.location.href = "shop.html";
});


//BLOCK LIST BUTTON
blockButton.addEventListener("click", () => {
    window.location.href = "block-list.html";
});

// RUPEE SAVE SYSTEM

chrome.storage.local.get(["rupees"], (result) => {
    const rupees = result.rupees || 0;

    console.log("MENU READ RUPEES:", result);

    if (rupeeCount) {
        animateRupees(0, rupees);
    } else {
        console.log("ERROR: rupee-display not found");
    }
});

// SAVE PLAYER CHECK
chrome.storage.local.get(["playerName"], (result) => {

    if (result.playerName) {
        playerNameDisplay.textContent = result.playerName;
        playEquippedMusic();
    } else{
        nameScreen.classList.remove("hidden");
        nameSelectMusic.play();
    }
    });
// NAME CONFRIM
    confirmButton.addEventListener("click", () => {
        const playerName = nameInput.value.trim();

        if (playerName === "") {
            return;
        }
        const confirmFinished = new Promise((resolve) => {
            confirmSound.addEventListener('ended', resolve, { once: true});
        });
        confirmSound.play();
        nameSelectMusic.pause();
        nameSelectMusic.currentTime = 0;
        
        chrome.storage.local.set({
            playerName: playerName
        });
       
        playerNameDisplay.textContent = playerName;

        nameScreen.classList.add("hidden");
        confirmFinished.then(() => {
            playEquippedMusic();
        });
    });

minishCapButton.addEventListener("click", () => {
        minishCaptitle.currentTime = 0;
        minishCaptitle.play();    
        window.location.href = "minish-cap.html";    
        });


//CREDITS BUTTON

creditsButton.addEventListener("click", () => {
    window.location.href = "credits.html";
});
