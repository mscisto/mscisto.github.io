
let lastUrl = location.href;

function checkCurrentUrl() {

    if (location.href !== lastUrl) {


        lastUrl = location.href;

        chrome.storage.local.get(
            ["activeQuest", "blockedSites"],
            (result) => {

                // No active quest = don't block anything
                if (!result.activeQuest) {
                    return;
                }

                const blockedSites = result.blockedSites || [];

                const currentDomain =
                    location.hostname.replace(/^www\./, "");

                const blockedSite = blockedSites.find(
                    site => site.domain === currentDomain
                );

                if (!blockedSite) {
                    return;
                }
                const exceptions = blockedSite.exceptions || [];
                const isException = exceptions.some(exception => exception === location.href);
        if (isException) {
            return;
            }  
        window.location.href = chrome.runtime.getURL(`blocked.html?site=${encodeURIComponent(currentDomain)}`);
            });}
}

setInterval(checkCurrentUrl, 500);