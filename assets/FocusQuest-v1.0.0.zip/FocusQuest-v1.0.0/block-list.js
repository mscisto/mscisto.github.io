let blockedSites = [];
const blockInput = document.getElementById("player-block-input");
const addSite = document.getElementById("add-site");
const ezlo = new Audio("assets/audio/ezlo.wav");
const blockNames = document.getElementById("block-list-names");
const backButton = document.getElementById("back-button");
const goronsound = new Audio("assets/audio/goronsound.wav");
const blocksound = new Audio("assets/audio/dungeon.mp3");

blocksound.volume = 0.3;
blocksound.loop = true;
goronsound.volume = 0.3;
ezlo.volume = 0.3;

blocksound.play();

chrome.storage.local.get(["blockedSites"], (result) => {
    blockedSites = (result.blockedSites || []).map((site) => {
        // Old 0.9.5 format
        if (typeof site === "string") {

            return {
                domain: site,
                exceptions: []
            };

        }
        // Already using V1 format
        return site;
  });
    chrome.storage.local.set({
        blockedSites: blockedSites
    });
    renderBlockedSites();

});
blockInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        addSite.click();
    }
});
addSite.addEventListener("click", () => {
   
    const site = blockInput.value.trim();
        if (site === "") {
        return;
    }
    let cleanSite = site
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0]
    .toLowerCase();
    const alreadyBlocked = blockedSites.some(
    blockedSite => blockedSite.domain === cleanSite);
    if(alreadyBlocked){
        return;
    }
        blockedSites.push({
            domain: cleanSite,
            exceptions: []
        });
        ezlo.play();
        chrome.storage.local.set({
            blockedSites: blockedSites,
        });
        blockInput.value = "";
        renderBlockedSites();
});

function renderBlockedSites () {
    blockNames.textContent= "";
    blockedSites.forEach((site, index) => {
        const siteRow = document.createElement("div");
        const siteHeader = document.createElement("div");
        siteHeader.className = "site-header";
        const exceptionList = document.createElement("div");
        exceptionList.className = "exception-list";
        site.exceptions.forEach((exception) => {
        const exceptionRow = document.createElement("div");
        exceptionRow.className = "exception-row";
        exceptionRow.textContent = exception;
        const removeExceptionButton = document.createElement("button");
        removeExceptionButton.textContent = "Remove";
        exceptionList.appendChild(exceptionRow);
        exceptionRow.appendChild(removeExceptionButton);
        removeExceptionButton.addEventListener("click", () => {
            site.exceptions = site.exceptions.filter(updatedException => updatedException !== exception );
            chrome.storage.local.set({
            blockedSites: blockedSites
            });
            goronsound.play();
    renderBlockedSites();
        }); 
    })
        const domainName = document.createElement("span");
        domainName.textContent = site.domain;
        siteHeader.appendChild(domainName);
        siteRow.appendChild(siteHeader);
        siteRow.appendChild(exceptionList);
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        siteHeader.appendChild(removeButton);
        blockNames.appendChild(siteRow);
        removeButton.addEventListener("click", () => {
            blockedSites = blockedSites.filter(updatedsite => updatedsite.domain !== site.domain);
            chrome.storage.local.set({
                blockedSites: blockedSites,
            });
            goronsound.play();
            renderBlockedSites();
        });
        const exceptionButton = document.createElement("button");
        exceptionButton.className = "Add Exception";
        siteRow.appendChild(exceptionButton);
        exceptionButton.textContent = "Add Exception";
        exceptionButton.addEventListener("click", () => {
            if(siteRow.querySelector(".exception-input")) {
                return;
            }
            const exceptionInput = document.createElement("input");
            const saveExceptionButton = document.createElement("button");
            saveExceptionButton.textContent = "Add";
            exceptionInput.className = "exception-input";
            exceptionInput.placeholder = "Paste allowed link";
            siteRow.appendChild(exceptionInput);
            siteHeader.appendChild(saveExceptionButton);
        saveExceptionButton.addEventListener("click", () => {
        const exceptionUrl = exceptionInput.value.trim();
        if (exceptionUrl === "") {
            return;
        }
        site.exceptions.push(exceptionUrl);
        chrome.storage.local.set({
            blockedSites: blockedSites
        });
        ezlo.play();
        renderBlockedSites();

});
        
});
});
}

backButton.addEventListener("click", () => {
    blocksound.pause();
    blocksound.currentTime = 0;
    window.location.href = "menu.html"
});